package br.com.poo.controlebiblioteca.emprestimo;

public interface InterfaceEmprestimo {
    public boolean emprestimo();
    public boolean devolucao();
}
